package br.com.curitiba;

import java.util.Random;
import java.util.Scanner;

public class Main {
    private static final int TAMANHO_MAR = 8;
    private static final char VAZIO = '-';
    private static final char NAVIO = 'N';
    private static final char ATINGIDO = 'X';
    private static final char AGUA = 'O';

    private char[][] tabuleiro;
    private int naviosRestantes;

    public Main() {
        tabuleiro = new char[TAMANHO_MAR][TAMANHO_MAR];
        naviosRestantes = 0;
        inicializarTabuleiro();
    }

    private void inicializarTabuleiro() {
        for (int i = 0; i < TAMANHO_MAR; i++) {
            for (int j = 0; j < TAMANHO_MAR; j++) {
                tabuleiro[i][j] = VAZIO;
            }
        }
    }

    public void adicionarNavio(int linha, int coluna) {
        if (linha < 0 || linha >= TAMANHO_MAR || coluna < 0 || coluna >= TAMANHO_MAR) {
            System.out.println("Posi��o inv�lida!");
            return;
        }

        if (tabuleiro[linha][coluna] == VAZIO) {
            tabuleiro[linha][coluna] = NAVIO;
            naviosRestantes++;
            System.out.println("Navio adicionado em (" + linha + ", " + coluna + ")");
        } else {
            System.out.println("Posi��o j� ocupada por outro navio!");
        }
    }

    public boolean atirar(int linha, int coluna) {
        if (linha < 0 || linha >= TAMANHO_MAR || coluna < 0 || coluna >= TAMANHO_MAR) {
            System.out.println("Posi��o inv�lida!");
            return false;
        }

        if (tabuleiro[linha][coluna] == NAVIO) {
            tabuleiro[linha][coluna] = ATINGIDO;
            naviosRestantes--;
            System.out.println("Acertou um navio!");
            return true;
        } else {
            tabuleiro[linha][coluna] = AGUA;
            System.out.println("Atirou na �gua");
            return false;
        }
    }

    public boolean jogoFinalizado() {
        return naviosRestantes == 0;
    }

    public void exibirTabuleiro() {
        for (int i = 0; i < TAMANHO_MAR; i++) {
            for (int j = 0; j < TAMANHO_MAR; j++) {
                System.out.print(tabuleiro[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Main jogo = new Main();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Jogador 1, adicione seus navios:");
        for (int i = 0; i < 3; i++) {
            System.out.print("Digite a linha do navio " + (i + 1) + ": ");
            int linha = scanner.nextInt();
            System.out.print("Digite a coluna do navio " + (i + 1) + ": ");
            int coluna = scanner.nextInt();
            jogo.adicionarNavio(linha, coluna);
        }

        Random random = new Random();
        
        int numeroAleatorio1 = random.nextInt(7) + 1; 
        
        int numeroAleatorio2;
        do {
            numeroAleatorio2 = random.nextInt(7) + 1;  
        } while (numeroAleatorio2 == numeroAleatorio1); 
        
        System.out.println("Computador posicione seus navios");
        for (int i = 0; i < 3; i++) {
            int linha = random.nextInt(7) + 1;
            int coluna = random.nextInt(7) + 1;
            
            System.out.println("Navio " + (i + 1) + ": Linha " + linha + ", Coluna " + coluna);
            jogo.adicionarNavio(linha, coluna);
        }

        while (!jogo.jogoFinalizado()) {
            System.out.print("Jogador 1, digite a linha do seu tiro: ");
            int linha = scanner.nextInt();
            System.out.print("Jogador 1, digite a coluna do seu tiro: ");
            int coluna = scanner.nextInt();
            jogo.atirar(linha, coluna);
            jogo.exibirTabuleiro();

            if (jogo.jogoFinalizado()) {
                System.out.println("Jogador 1 venceu!");
                break;
            }

            Random random2 = new Random();
            
            int numeroAleatorio3 = random2.nextInt(7) + 1; 
            
            int numeroAleatorio4;
            do {
                numeroAleatorio4 = random2.nextInt(7) + 1;  
            } while (numeroAleatorio4 == numeroAleatorio3); 
            
            System.out.print("Computador, digite a linha do seu tiro: ");
            int linhaComputador = random2.nextInt(7) + 1;
            System.out.print("Computador, digite a coluna do seu tiro: ");
            int colunaComputador = random2.nextInt(7) + 1;
            
            jogo.atirar(linhaComputador, colunaComputador);
            jogo.exibirTabuleiro();
        }

        System.out.println("Jogador 2 venceu!");
        scanner.close();
    }
}